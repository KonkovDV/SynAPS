from .synaps_native import *

__doc__ = synaps_native.__doc__
if hasattr(synaps_native, "__all__"):
    __all__ = synaps_native.__all__